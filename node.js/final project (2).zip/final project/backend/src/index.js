const express=require('express')
const cors=require('cors')
const mongoose=require('mongoose')
const app=express()

const userRoutes=require('./routes/auth.js')
const adminRoutes=require('./routes/admin/auth.js')
const categoryRoutes=require('./routes/category.js')
const productRoutes=require('./routes/product.js')
const cartRoutes=require('./routes/cart.js')

mongoose.connect('mongodb://0.0.0.0:27017/ecommerce').then(()=>{
    console.log("Database Connected")
})

app.use(express.json())
app.use(cors())

app.use('/api',userRoutes)
app.use('/',adminRoutes)
app.use('/api',categoryRoutes)
app.use('/api',productRoutes)
app.use('/api',cartRoutes)

app.listen(4000)



// cors install hai backend frontend cmd simultanously run karnyastahi a

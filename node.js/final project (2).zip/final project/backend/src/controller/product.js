const Product=require("../models/product")
const shortid=require('shortid')
const category=require('../models/category')
const slugify=require('slugify')
const fs=require('fs')
const { populate } = require("../models/auth")

exports.createProduct=async(req,resp)=>{
    try{
    const {name,price,description,slug,category,quantity}=req.fields
   const {photo}=req.files
   switch(true)
   {
    case !name:
        return resp.status(500).send({error:"Name is required"})
    case !description:
        return resp.status(500).send({error:"description is required"})
    case !price:
        return resp.status(500).send({error:"price is required"})
    case !quantity:
        return resp.status(500).send({error:"quantity is required"})
    case !category:
        return resp.status(500).send({error:"category is required"})    
    case !photo && photo.size > 10000:
        return resp.status(500).send({error:"photo is required and should be less than 1 Mb"})   
   }
   const product =new Product({...req.fields,slug:slugify(name)})
   if(photo)
   {
    product.photo.data=fs.readFileSync(photo.path)
    product.photo.contentType=photo.type
   }
   await product.save()
   resp.status(201).send({
    success:true,
    message:"Product created succesfully",
    product
   })
}catch(error){
    resp.status(500).send({
         success: false,
            error,
            message: "Error in creating product"
       })
}
  
}

exports.getProducts=async(req,resp)=>{
    try{
        const product=await Product.find({}).select("-photo").limit(10).sort({createdAt:-1}).populate("category")
        resp.status(200).send({
            success:true,
            total:product.length,
            message:"Error in getting products",
            error:error.message
        })
    }catch(error){
        resp.status(500).send({
            success:false,
            message:" Error in getting Product ",
            error:error.message
           })
    }
}

exports.getSingleProducts=async(req,resp)=>{
    try{
        const product=await Product.findOne({slug:req.params.slug}).select("-photo").populate("category")
        resp.status(200).send({
            success:true,
            total:product.length,
            message:"Single Product Fetched",
            product
        })
    }catch(error){
        resp.status(500).send({
            success:false,
            message:" Error in getting single Product ",
            error
           })
    }
}

exports.getProductphoto=async(req,resp)=>{
    try{
        const product=await Product.findById(req.params.pid).select("photo")
        if(product.photo.data)
        {
            resp.set('Content-type',product.photo.contentType)
            return resp.status(200).send(product.photo.data)
        } 
    }catch(error){
            resp.status(500).send({
                success:false,
                message:"Error getting Product Photo",
                error

            })
        }
    
}

exports.productDelete=async(req,resp)=>{
    try{
        await Product.findByIdAndDelete(req.params.pid).select("-photo")
        resp.status(200).send({
            success:true,
            
            message:" Product deleted successfully",
        })

    }catch(error){
        resp.status(500).send({
            success:false,
            
            message:" Error deleting Product",
        })
    }
}

exports.updateProduct=async(req,resp)=>{
    try{
        const {name,price,description,slug,category,quantity}=req.fields
       const {photo}=req.files
       switch(true)
       {
        case !name:
            return resp.status(500).send({error:"Name is required"})
        case !description:
            return resp.status(500).send({error:"description is required"})
        case !price:
            return resp.status(500).send({error:"price is required"})
        case !quantity:
            return resp.status(500).send({error:"quantity is required"})
        case !category:
            return resp.status(500).send({error:"category is required"})    
        case !photo && photo.size > 10000:
            return resp.status(500).send({error:"photo is required and should be less than 1 Mb"})   
       }
       const product = await Product.findByIdAndUpdate(req.params.pid,{...req.fields,slug:slugify(name)},{new:true})
       if(photo)
       {
        product.photo.data=fs.readFileSync(photo.path)
        product.photo.contentType=photo.type
       }
       await product.save()
       resp.status(201).send({
        success:true,
        message:"Product updated succesfully",
        product
       })
    }catch(error){
        resp.status(500).send({
            success:false,
            message:" Error in updating Product ",
            product
           })
    }
      
}
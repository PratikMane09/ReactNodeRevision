const express=require('express')
const { createProduct, getProducts, updateProduct, getSingleProducts, productDelete, getProductphoto } = require('../controller/product')
const multer=require('multer')
const router=express.Router()
const formidable=require('express-formidable')




router.get('/product/getproducts',getProducts)
router.post('/product/create',formidable(),createProduct)
router.get('/product/getsingleproduct/:slug',getSingleProducts)
router.get('/product/getphoto/:pid',getProductphoto)
router.delete('/product/delete/:pid',productDelete)
router.put('/product/update/:pid',updateProduct)



module.exports=router
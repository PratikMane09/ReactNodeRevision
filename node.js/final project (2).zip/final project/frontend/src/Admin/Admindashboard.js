import React from 'react'

function Admindashboard() {
  return (
    <div>Admindashboard</div>
  )
}

export default Admindashboard
import { createContext, useContext, useState } from "react"

const Authcontext=createContext()
const AuthProvider=({childern})=>{
    const [auth,setAuth]=useState({
        user:null,
        token:""
    })
    return(
        <Authcontext.Provider value={[auth,setAuth]}>
            {childern}
        </Authcontext.Provider>
    )
}
const useAuth=()=>useContext(Authcontext)
export {useAuth,AuthProvider}
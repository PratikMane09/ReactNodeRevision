
import './App.css';
import Header from './components/Header'
import {BrowserRouter, Route, Routes,} from 'react-router-dom'
import Signin from './components/Signin';
import Home from './components/Home';
import Signup from './components/Signup';
import Categories from './components/Categories';
import Product from './components/Product';
import Orders from './components/Orders';
import Signout from './components/Signout';
import Private from './components/Private';
import Userdashboard from './user/Userdashboard';
import PrivateRoute from './Routes/Private';
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header/>
        
        <Routes>
          <Route element={<Private/>}>
          <Route path='/Home' element={<Home/>}/>
          <Route path='/Userdashboard' element={<PrivateRoute/>}>
          <Route path='' element={<Userdashboard/>}/>
          </Route>

          <Route path='/Categories' element={<Categories/>}/>
          <Route path='/Product' element={<Product/>}/>
          <Route path='/Orders' element={<Orders/>}/>
          </Route>
          <Route path='/Signin' element={<Signin/>}/>
          <Route path='/Signup' element={<Signup/>}/>
          <Route path='/Signout' element={<Signout/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
 
import React, { useEffect, useState } from 'react'
import ListGroup from 'react-bootstrap/ListGroup';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
function Categories(){
    const [Categories,setcategories]=useState([])
    const[parentId,setParentId]=useState("")
    const[name,setName]=useState("")
    const[type,setType]=useState("")
    function getcategories(){
        fetch("http://localhost:4000/api/category/getcategory").then((resp1)=>{
            resp1.json().then((resp2)=>{
                console.log(resp2)
                setcategories(resp2.error)
            })
        })
        
    }
    useEffect(()=>{
        getcategories()
    },[])
    function addcategory(e){
        e.preventDefault()
        
        fetch(`http://localhost:4000/api/category/create`,{
          method:"POST",
          headers:{
            'content-Type':"application/json"
          }, 
          body:JSON.stringify({parentId,name,type})
        }).then((res1)=>{
          res1.json().then((res2)=>{
            getcategories()
          })
        })
      
      }
      
    return(
        <div className='container mt-5'>
            <h2>List of Categories</h2>
    <ListGroup>
      {
        Categories.map((item,index) =>{
            
            return(
                <ListGroup.Item variant="primary" key={index} className='d-flex justify-content-between align-items-center'>
                <span>{item.parentId}</span>
                <span >{item.name.charAt(0).toUpperCase() + item.name.slice(1)}</span>
                <span >{item.type.charAt(0).toUpperCase() + item.type.slice(1)}</span>
                </ListGroup.Item>
            )
            
        })
      }
      
    </ListGroup>
    <h1 className='mt-4'>Add New Category</h1>
    <Form>
      <Form.Group as={Row} className="mb-3" controlId="formHorizontaltext">
        <Form.Label column sm={2}>
          parentId:
        </Form.Label>
        <Col sm={10}>
          <Form.Control type="text" placeholder="Parent Id"
          value={parentId} onChange={(e)=>setParentId(e.target.value)} />
        </Col>
      </Form.Group>

      <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
        <Form.Label column sm={2}>
          Product Name:
        </Form.Label>
        <Col sm={10}>
          <Form.Control type="text" placeholder="Product Name" value={name} onChange={(e)=>setName(e.target.value)}/>
        </Col>
      </Form.Group>

      <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
        <Form.Label column sm={2}>
          Type:
        </Form.Label>
        <Col sm={10}>
          <Form.Control type="text" placeholder="Category Type" value={type} onChange={(e)=>setType(e.target.value)} />
        </Col>
      </Form.Group>
     
     

      <Form.Group as={Row} className="mb-3">
        <Col sm={{ span: 10, offset: 2 }}>
          <Button type="submit" onClick={addcategory}>Add category</Button>
        </Col>
      </Form.Group>
    </Form>
</div>
    )
}

export default Categories
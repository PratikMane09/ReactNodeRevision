import React from 'react'
import {Link} from 'react-router-dom'
export default function Home() {
  return (
    < div className='container'>
      <h1 className='me-auto my-2 my-lg-0'>Welcome to Online Shopping</h1>
      <div className='row'>
        <div className='col-2 border border-2 d-flex flex-column p-4'>
          <Link to={'/Categories'} className='text-dark text-decoration-none'><h2>Categories</h2></Link>
          <Link to={'/Products'} className='text-dark text-decoration-none'><h2>Products</h2></Link>
        </div>
        <div className='col-10'>
          
        </div>
      </div>
    </div>
  )
}

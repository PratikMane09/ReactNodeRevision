import React,{useState,useEffect} from 'react'
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
export default function Singleproduct() {
    const [products,setProducts]=useState([])
  const [name,setName]=useState("")
  const [price,setPrice]=useState(0)
  const [quantity,setQuantity]=useState(1)
  const [description,setDescription]=useState("")
  const [photo,setPhoto]=useState("")
  const [categories,setCategories]=useState([])
  const [category,setCategory]=useState("")  
   const [id,setId]=useState("")
  return (
    <div>
          <Form>
              <Form.Select aria-label="Default select example" className='mb-3' name={category}
                  onChange={(e) => setCategory(e.target.value)} value={category.name}>
                  {
                      categories.map((c) => {
                          return (
                              <option key={c._id} value={c._id}>{c.name}</option>)
                      })
                  }
              </Form.Select>
              <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={2}>
                      Product Name:
                  </Form.Label>
                  <Col sm={10}>
                      <Form.Control type="text" placeholder="Product Name" value={name}
                          onChange={(e) => setName(e.target.value)} />
                  </Col>
              </Form.Group>

              <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                  <Form.Label column sm={2}>
                      Price:
                  </Form.Label>
                  <Col sm={10}>
                      <Form.Control type="text" placeholder="Product Price" value={price}
                          onChange={(e) => setPrice(e.target.value)} />
                  </Col>
              </Form.Group>

              <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={2}>
                      Quantity:
                  </Form.Label>
                  <Col sm={10}>
                      <Form.Control type="text" placeholder="Quantity" value={quantity}
                          onChange={(e) => setQuantity(e.target.value)} />
                  </Col>
              </Form.Group>
              <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={2}>
                      Description:
                  </Form.Label>
                  <Col sm={10}>
                      <Form.Control type="text" placeholder="Description" value={description}
                          onChange={(e) => setDescription(e.target.value)} />
                  </Col>
              </Form.Group>
              <Form.Group controlId="formFile" className="mb-3">
                  <Form.Label>Upload Product Picture</Form.Label>
                  <Form.Control type="file" name='photo' accept='image/*'
                      onChange={(e) => setPhoto(e.target.files[0])} hidden />
              </Form.Group>
              {photo ? (<div className='text-center'>
                  <img src={URL.createObjectURL(photo)}
                      alt='product image' height={"200px"}
                      className='img-fluid' />
              </div>) : (<div className='text-center'>
                  <img src={`http://localhost:4000/api/product/getphoto/${item._id}`}
                      alt='product image' height={"200px"}
                      className='img-fluid' />
              </div>)}

          </Form>
    </div>
  )
}
import React from 'react'

export default function Footer() {
  return (
    <div className='bg-dark text-light p-3'>
        <h4 className='text-center'>
            All Rights Reserved &copy; Online Shopping
        </h4>
    </div>
  )
}
